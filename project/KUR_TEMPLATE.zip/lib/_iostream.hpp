#pragma once
#include<iostream>
#define __KUR_ENABLE_IOSTREAM