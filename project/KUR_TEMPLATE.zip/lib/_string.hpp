#pragma once
#include<string>
#define __KUR_ENABLE_STRING