#pragma once
#include"dev.hpp"
#include"_iostream.hpp"
#include"_string.hpp"
#include"utility.hpp"
#include"plus.hpp"

namespace kur{
    using namespace KUR;
    using namespace KUR::LB2022;
    using namespace KUR::LB2023;
    using namespace KUR::base;
    using namespace KUR::plus;
    using namespace KUR::LB2022::ConsoleColor;
    using namespace KUR::LB2022::thread;
    using namespace KUR::LB2022::others;
    using namespace KUR::LB2023::Keyboard;
    using namespace KUR::LB2023::sys;
    using namespace KUR::LB2023::thread;
}