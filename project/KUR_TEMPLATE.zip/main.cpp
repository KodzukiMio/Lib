﻿#include<iostream>
#include"lib/utility.hpp"
struct Types{
    int a;
    short b;
};
int main(){
    KUR::ByteArray<KUR::ByteN<128>>arr;
    arr[4] = 0xab;
    arr[3] = 0xee;
    arr.range<0,3>() = 0xdddddd;
    KUR::byte4 b2 = 0xcdefedcc;
    arr.at(4) = b2;
    arr.print_range_hex(0,10);
    auto& tys = arr.refbytes<Types>(0,1);
    std::cout << std::endl;
    std::cout << "VALUE:\na:" << std::hex << tys.a << std::endl << "b:" << tys.b;
    return 0;
}
